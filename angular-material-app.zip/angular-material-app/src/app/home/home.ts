import { Component } from '@angular/core';
import { MatTabsModule } from '@angular/material/tabs';
import { SearchTab1 } from '../search-tab1/search-tab1';
import { SearchTab2 } from '../search-tab2/search-tab2';
import { SearchTab3 } from '../search-tab3/search-tab3';

@Component({
  selector: 'app-home',
  imports: [MatTabsModule, SearchTab1, SearchTab2, SearchTab3],
  templateUrl: './home.html',
  styleUrl: './home.scss'
})
export class Home {
  
}
