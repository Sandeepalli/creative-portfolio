import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-search-tab1',
  imports: [FormsModule, MatFormFieldModule, MatInputModule, MatButtonModule, MatIconModule],
  templateUrl: './search-tab1.html',
  styleUrl: './search-tab1.scss'
})
export class SearchTab1 {
  searchQuery: string = '';
  
  onSearch(): void {
    console.log('Search 1:', this.searchQuery);
  }
}
